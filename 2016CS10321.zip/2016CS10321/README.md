# Red-Jack
Reinforcement Learning based bot for the game of Red-Jack (extension of popular casino game BlackJack)
